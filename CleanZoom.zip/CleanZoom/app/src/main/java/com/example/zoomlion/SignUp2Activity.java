package com.example.zoomlion;


import android.content.Intent;
import android.os.Bundle;

import android.support.v7.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
;



public class SignUp2Activity extends AppCompatActivity {



    private EditText email, password, confirmpass;
    private Button nxt;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up2);
        nxt = findViewById(R.id.nextButton);
        email = findViewById(R.id.EmailText);
        password = findViewById(R.id.login_password);

        nxt.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent StartActivity2 = new Intent(SignUp2Activity.this, SignUp2Activity .class);
            startActivity(StartActivity2);
        }
    });}}

