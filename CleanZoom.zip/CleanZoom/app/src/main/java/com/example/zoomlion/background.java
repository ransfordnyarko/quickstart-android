package com.example.zoomlion;

import android.os.AsyncTask;

public class background extends AsyncTask <String, Void,String> {
    @Override
    protected String doInBackground(String... voids) {

        String result = "";

        return result;
    }
}
