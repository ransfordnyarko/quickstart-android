package com.example.zoomlion;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


public class SignUpActivity3 extends AppCompatActivity {

    private EditText FirstName, LastName, Phone,Country, School;




    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        FirstName = (EditText) findViewById(R.id.FirstNameText);
        LastName = (EditText) findViewById(R.id.LastNameText);
        Phone = (EditText) findViewById(R.id.Phone);
        Country = (EditText) findViewById(R.id.CountryText);
        School = (EditText) findViewById(R.id.SchoolText);





    }

    public void NextActivity2(View view) {
        String fname = FirstName.getText().toString();
        String lname = LastName.getText().toString();
        String phone = Phone.getText().toString();
        String ctry = Country.getText().toString();
        String sch = School.getText().toString();

        if(TextUtils.isEmpty(fname)){
            Toast.makeText(this, "Please enter Name", Toast.LENGTH_SHORT).show();
            return;
        }



        Intent StartActivity3 = new Intent(this, MainActivity.class);
        startActivity(StartActivity3);
    }
}
