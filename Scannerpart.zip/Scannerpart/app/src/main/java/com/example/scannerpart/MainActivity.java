package com.example.scannerpart;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public static TextView resultView;
    Button scan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        resultView=  findViewById(R.id.result_text);
        scan =  findViewById(R.id.scan_btn);
    }

    public void ScanActivity (View view) {
        startActivity(new Intent(getApplicationContext(),ScanCodeActivity.class));
    }
}
